/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/utils/bookmark-manager.ts
class BookmarkManager {
    async createBookmark(url, title, folderPath) {
        const folderId = await this.ensureFolderPath(folderPath);
        return chrome.bookmarks.create({
            parentId: folderId,
            title,
            url
        });
    }
    async ensureFolderPath(path) {
        let currentId = '1'; // Bookmarks menu ID
        for (const folderName of path) {
            const existingFolder = await this.findFolder(currentId, folderName);
            if (existingFolder) {
                currentId = existingFolder.id;
            }
            else {
                const newFolder = await chrome.bookmarks.create({
                    parentId: currentId,
                    title: folderName
                });
                currentId = newFolder.id;
            }
        }
        return currentId;
    }
    async findFolder(parentId, name) {
        const children = await chrome.bookmarks.getChildren(parentId);
        return children.find(child => child.title === name && !child.url) || null;
    }
}

;// ./src/background/service-worker.ts

class BackgroundService {
    constructor() {
        console.log('BackgroundService initializing...');
        this.bookmarkManager = new BookmarkManager();
        this.initializeListeners();
        console.log('BackgroundService initialized successfully');
    }
    initializeListeners() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log('Received message:', request);
            this.handleMessage(request, sender, sendResponse);
            return true; // Keep message channel open for async response
        });
        // Add installation and startup listeners
        chrome.runtime.onInstalled.addListener((details) => {
            console.log('Extension installed/updated:', details);
        });
        chrome.runtime.onStartup.addListener(() => {
            console.log('Extension startup');
        });
    }
    async handleMessage(request, sender, sendResponse) {
        console.log('Handling message:', request.action);
        try {
            switch (request.action) {
                case 'CREATE_BOOKMARK':
                    const { url, title, classification } = request.data;
                    console.log('Creating bookmark:', { url, title, classification });
                    const bookmark = await this.bookmarkManager.createBookmark(url, title, classification.folderPath);
                    console.log('Bookmark created successfully:', bookmark);
                    sendResponse({ success: true, bookmark });
                    break;
                default:
                    console.warn('Unknown action:', request.action);
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        }
        catch (error) {
            console.error('Error handling message:', error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
            sendResponse({ success: false, error: errorMessage });
        }
    }
}
// Initialize the service
console.log('Starting BackgroundService...');
new BackgroundService();

/******/ })()
;
//# sourceMappingURL=service-worker.js.map